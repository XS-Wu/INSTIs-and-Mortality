
# R version 4.2.1
# R studio version 2022.7.1.554

# Install packages only for first use
# install.packages('sandwich')
# install.packages('broom')
# install.packages('lmtest')
# install.packages('nortest')
# install.packages('survival')
# install.packages('survminer')
# install.packages('boot')

# Load packages
library(sandwich)
library(broom)
library(lmtest)
library(nortest)
library(survival)
library(survminer)
library(boot)
# -----------------------------------------------------------------------

# Read the simulated data
dat<-read.csv("SimulatedSample.csv")

# Convert variables to factors
dat$agegroup <- factor(dat$agegroup)     # Age group
dat$sex <- factor(dat$sex)               # Sex
dat$trans <- factor(dat$trans)           # Route of Transmission
dat$region <- factor(dat$region)         # Region
dat$time_to_ART <- factor(dat$time_to_ART)   # Time to ART initiation
dat$ARTyear <- factor(dat$ARTyear)       # Year of ART initiation
dat$initial_ART <- factor(dat$initial_ART)   # Initial ART regimen
dat$backbone <- factor(dat$backbone)     # Backbone
dat$initial_cd4 <- factor(dat$initial_cd4)   # Initial CD4 count


######## Kaplan-Meier Survival Curve ########

# Fit survival model using initial ART regimen as a predictor
surv_fit<- survfit(Surv(t, death) ~ initial_ART, data = dat)      # t= Time from ART initiation (year)

# Create a survival plot
surv_plot<-ggsurvplot(surv_fit,
                      data=dat,
                      conf.int=F,
                      pval=T,
                      pval.size=5,
                      censor=F,
                      legend.title="Initial ART regimen",
                      xlab="Years from ART initiation",
                      ylab="Cumulative incidence of mortality",
                      risk.table.title="",
                      size = 0.8,
                      risk.table=T,
                      risk.table.height=.3,
                      fun = "event")
surv_plot


##### Adjusted Poisson Regression Model #####

# Multivariate Poisson regression model with a time offset and robust variances
poisson_fit <- glm(death~ agegroup + sex + trans + region + time_to_ART + ARTyear + initial_ART + initial_cd4 + backbone, data=dat, offset = log(t), poisson(link='log'))

# Breusch-Pagan test for heteroscedasticity
bptest(poisson_fit)

# Compute robust standard errors
se <- sqrt(diag(vcovHC(poisson_fit, type = "HC1")))

# Anderson-Darling test for normality
residuals <- resid(poisson_fit, type = "pearson")
ad_test <- ad.test(residuals)
print(ad_test)

# Summarize the results
summary <- tidy(poisson_fit)
summary$se <- se
summary$OR <- sprintf("%0.2f", exp(summary$estimate))
summary$CI_l <- sprintf("%0.2f", exp(summary$estimate - 1.96 * se))
summary$CI_u <- sprintf("%0.2f", exp(summary$estimate + 1.96 * se))
summary$p.value <- sprintf("%0.3f", 2 * pnorm(abs(coef(poisson_fit)/se), lower.tail=FALSE))
summary$irr <- paste0(summary$OR,"(",summary$CI_l,"-",summary$CI_u,")")

# Print the result table
print(summary)


#### Cox Proportional Hazards Model ####

# Multivariate Cox model
cox_fit <- coxph(Surv(t, death)~ agegroup + sex + trans + region + time_to_ART + ARTyear + initial_ART + initial_cd4 + backbone, data=dat)

# Check the proportional hazards assumption
test.ph <- cox.zph(cox_fit)
test.ph
ggcoxzph(test.ph)

# Extract summary information from the model
cox_fit_summary <- summary(cox_fit)
hazard_ratios <- sprintf("%0.2f", cox_fit_summary$coefficients[, "exp(coef)"])
conf_intervals <- exp(confint(cox_fit))
p_values <- sprintf("%0.3f", cox_fit_summary$coefficients[, "Pr(>|z|)"])

# Create a data frame with the results
result_table <- data.frame(Hazard_Ratio = hazard_ratios,
                           Lower_CI = sprintf("%0.2f", conf_intervals[, 1]),
                           Upper_CI = sprintf("%0.2f", conf_intervals[, 2]),
                           HR= paste0(hazard_ratios,"(",sprintf("%0.2f", conf_intervals[, 1]),"-",sprintf("%0.2f", conf_intervals[, 2]),")"),
                           p_value = p_values)

# Print the result table
print(result_table)
